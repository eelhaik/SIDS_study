USA Hispanics vs. SIDS plot. USA state wise Hispanics (%) and SIDS data are in the file Hispanics vs. SIDS data.txt
The plot was created using GraphPad Prism based on the data in the excel file

