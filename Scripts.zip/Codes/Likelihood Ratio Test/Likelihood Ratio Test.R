a <- read.table("multfact2factors.txt", header=T)
a
model0 <- glm(a$SIDS ~ a$Circumcision)
model1 <- glm(a$SIDS ~ a$Preterm)
model3 <- glm(a$SIDS ~ a$Circumcision+a$Preterm)
library(lmtest)
lrtest (model0, model3) # MNC vs. MNC+Preterm
lrtest (model1, model3) # Preterm vs. MNC+Preterm
