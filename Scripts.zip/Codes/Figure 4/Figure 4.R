a <- read.table("SIDS.txt", header=T)
a
ks.test(a$Anglophone, a$NonAnglophone)
t.test(a$Anglophone, a$NonAnglophone)
boxplot(a$Anglophone, a$NonAnglophone, ylab="SIDS prevalence (per 1000 birth)", names=c("Anglophone", "Non Anglophone"), main="Comparing SIDS prevalence between Anglophone and Non Anglophone countries")
b <- read.table("circum.txt", header=T)
b
ks.test(b$Anglophone, b$NonAnglophone)
t.test(b$Anglophone, b$NonAnglophone)
boxplot(b$Anglophone, b$NonAnglophone, ylab="MNC rate(%)", names=c("Anglophone", "Non Anglophone"), main="Comparing MNC rate(%) between Anglophone and Non Anglophone countries")