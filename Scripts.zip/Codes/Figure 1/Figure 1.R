par(mfrow=c(1,1))
a <- read.table("/Users/priyankaupadhyai/desktop/ISO3.txt", header=T)
a
library(rworldmap)
SIDS <- data.frame(country = a$ISO3_code, SIDS = a$SIDS)
SIDSMap <- joinCountryData2Map(SIDS, joinCode = "ISO3",nameJoinColumn = "country")
mapCountryData(SIDSMap, nameColumnToPlot="SIDS", missingCountryCol = gray(.8), borderCol = "black", mapTitle = "Global SIDS Prevalence (per 1000 birth")
library(maptools)
inFile <- "/Users/priyankaupadhyai/desktop/tl_2009_us_stateec/tl_2009_us_stateec.shp"
sPDF <- readShapePoly(inFile)
str(sPDF@data)
dF <- read.table("/Users/priyankaupadhyai/desktop/states.txt",header=T)
dF
str(dF)
sPDF2 <- joinData2Map(dF, nameMap = sPDF , nameJoinIDMap = "STUSPSEC" , nameJoinColumnData = "States")
mapPolys(sPDF2,nameColumnToPlot = "Prevalence",mapRegion="North America",missingCountryCol = gray(.8), borderCol = "black")