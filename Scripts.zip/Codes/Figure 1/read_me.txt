Global and US state wise SIDS data. Global data is in the file ‘ISO3.txt’ and US state wise SIDS data is in ‘states.txt’. US map is generated using the shape file ‘tl_2009_us_stateec.shp’ which is inside ‘tl_2009_us_stateec’ folder.

 The figure uses different colors than the one in the R code to make a parity in the color codes between the USA prevalence map and the Global prevalence map. 
 We created this map in Adobe Photoshop using criteria mentioned in the 'ISO3-SIDS' excel file.
 