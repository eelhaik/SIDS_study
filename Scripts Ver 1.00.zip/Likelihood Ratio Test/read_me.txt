Likelihood Ratio Test in a linear regression framework performed using the R package ‘epicalc’. 
The data are in the files 'multfact2factors_countries.txt' and 'multfact2factors_states.txt'