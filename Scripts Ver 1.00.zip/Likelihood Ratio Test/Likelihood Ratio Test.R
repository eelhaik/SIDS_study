a <- read.table("multfact2factors_states.txt", header=T)
#a <- read.table("multfact2factors_countries.txt", header=T)
a
model0 <- glm(a$SIDS ~ a$Circumcision)
model1 <- glm(a$SIDS ~ a$Preterm)
model3 <- glm(a$SIDS ~ a$Circumcision+a$Preterm)
library(lmtest)
lrtest (model0, model3) # MNC vs. MNC+Preterm
lrtest (model1, model3) # Preterm vs. MNC+Preterm

#Correlation betwen Preterm and MNC
df <- data.frame(x = a$Preterm, y= a$Circumcision)
mod <- lm(y ~ x, data = df)
#cat("N =", nrow(a), "r =", cor(a$Preterm, a$Circumcision), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
