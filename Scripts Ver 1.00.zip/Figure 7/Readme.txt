USA state wise prematurity vs. SIDS plot. 

The data are in US_SIDS.txt file.