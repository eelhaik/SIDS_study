#Comparing MNC rates in Anglophone VS non-Anglophone
b <- read.table("circum.txt", header=T)
b
ks.test(b$Anglophone, b$NonAnglophone)

#tiff(file="Figure 4b.tiff", width = 3200, height = 3600, units = "px", res=600)
boxplot(b$Anglophone, b$NonAnglophone, ylab="MNC rate (%)", names=c("Anglophone", "Non-Anglophone"), main="Comparing MNC rates (%) between \n Anglophone and non-Anglophone countries", xlim = c(0.5, 2.5), ylim = c(0, 60), frame=F)
#dev.off()


#Comparing SIDS rates in Anglophone VS non-Anglophone
a <- read.table("SIDS.txt", header=T)
a
ks.test(a$Anglophone, a$NonAnglophone)
#tiff(file="Figure 4a.tiff", width = 3200, height = 3600, units = "px", res=600)
boxplot(a$Anglophone, a$NonAnglophone, ylab="SIDS prevalence (per 1000 birth)", names=c("Anglophone", "Non-Anglophone"), main="Comparing SIDS prevalence between \n Anglophone and non-Anglophone countries", xlim = c(0.5, 2.5), ylim = c(0, 1.2), frame=F)
#dev.off()


