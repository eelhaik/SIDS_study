Comparing MNC and SIDS among Anglophone and Non-Anglophone countries. 

MNC data are in circum.txt 
SIDS data is in SIDS.txt

