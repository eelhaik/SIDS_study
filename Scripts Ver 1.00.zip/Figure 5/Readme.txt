Male/Female SIDS ratio VS MNC rate in USA
------------------------------

Data are in SIDS_Ratio_USA.txt

