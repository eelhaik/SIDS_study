a <- read.table("SIDS_Ratio_USA.txt", header=T)
a
df <- data.frame(x = a$MNC, y= a$Ratio)

#tiff(file="Figure 5.tiff", width = 4200, height = 3200, units = "px", res=600)
plot(y ~ x, bg=as.character(a$bg), xlim = c(0, 100), ylim = c(0.5, 2.5), xlab="MNC rate(%) ", ylab="Male/Female SIDS Ratio", pch=a$pch, data = df, cex=1, bty="n")


mod <- lm(y ~ x, data = df)
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), interval = 'confidence')
abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(a), "r =", cor(a$MNC, a$Ratio), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#dev.off()

library(Rmisc)
CI(a$Ratio,
   ci=0.95)

group.CI(MNC ~ Ratio, 
         data=a, 
         ci = 0.95)
