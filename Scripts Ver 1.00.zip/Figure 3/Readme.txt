Global MNC versus SIDS plot
------------------------------

Global MNC and SIDS data are in the file circum-SIDS.txt