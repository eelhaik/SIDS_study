par(mfrow=c(1,1))
a <- read.table("Countries.txt", header=T)
a
library(rworldmap)
SIDS <- data.frame(country = a$ISO3_code, SIDS = a$SIDS)
SIDSMap <- joinCountryData2Map(SIDS, joinCode = "ISO3",nameJoinColumn = "country")
color_vec <- c(0, 0.2, 0.4, 0.6, 0.8, 1, 5)
#tiff(file="Countries.tiff", width = 4800, height = 3200, units = "px", res=800)
mapCountryData(SIDSMap, nameColumnToPlot="SIDS", missingCountryCol = gray(1), borderCol = "black", catMethod = color_vec, mapTitle = "Global SIDS prevalence (per 1000 births)")


library(maptools)
inFile <- "tl_2009_us_stateec/tl_2009_us_stateec.shp"
sPDF <- readShapePoly(inFile)
str(sPDF@data)
dF <- read.table("States.txt",header=T)
dF
str(dF)
sPDF2 <- joinData2Map(dF, nameMap = sPDF , nameJoinIDMap = "STUSPSEC" , nameJoinColumnData = "States")
#tiff(file="States.tiff", width = 4800, height = 3200, units = "px", res=800)
mapPolys(sPDF2,nameColumnToPlot = "SIDS",mapRegion="North America",missingCountryCol = gray(1), catMethod = color_vec, borderCol = "black", mapTitle = "US SIDS prevalence")
#dev.off()
