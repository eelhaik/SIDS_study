Global and US state wise SIDS data
-----------------------------------
Global SIDS data (Table S1) is in the file 'ISO3.txt' 
US state-wise SIDS data (Table S6) is in 'states.txt'. 

US map is generated using the shape file 'tl_2009_us_stateec.shp' which is inside 'tl_2009_us_stateec' folder.

 
