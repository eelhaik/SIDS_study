USA Hispanics vs. SIDS plot. 
----------------------------
USA state wise Hispanics (%) and SIDS data are in the file Hispanics_SIDS data;

