a <- read.table("Hispanics_SIDS data.txt", header=T)
a
df <- data.frame(x = a$Hispanic, y= a$SIDS)

#tiff(file="Figure 2.tiff", width = 4200, height = 3200, units = "px", res=600)
plot(y ~ x, xlim = c(0, 0.5), ylim = c(0, 2), bg = as.character(a$Color_code), xlab="Hispanics (%) ", ylab="SIDS prevalence (per 1000 births) ", pch=21, col='black', data = df, cex=1, bty="n")

mod <- lm(y ~ x, data = df)
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), interval = 'confidence')
abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')
summary(mod)
cat("N =", nrow(a), "r =", cor(a$Hispanic, a$SIDS), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#dev.off()
