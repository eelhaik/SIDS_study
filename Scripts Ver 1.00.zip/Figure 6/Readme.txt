Global prematurity vs. SIDS plot. 
------------------------------

Global SIDS and prematurity data are in SIDS_prematurity.
