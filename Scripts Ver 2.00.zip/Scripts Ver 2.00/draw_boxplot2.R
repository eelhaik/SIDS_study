draw_boxplot2 <- function(x, x_name, y, y_low, y_high, test, alternative){
  #draw_boxplot <- function(x, x_name, y, weight, y_low, y_high){
  options(warn=-1)
  df <- data.frame(x, y)
  #df <- data.frame(x, y, weight)
  
  df <- na.omit(df) #remove missing values
  
  # Box plot with mean points
  p <- ggplot(df, aes(x=y, y=x, fill=y)) + geom_boxplot(notch=FALSE)
  p <- p + stat_summary(fun.y=mean, geom="point", shape=23, size=4) + geom_jitter(shape=16, position=position_jitter(0.2)) + scale_x_discrete(breaks=c("21","22"), labels=c("MNC is covered","MNC is not covered")) +  scale_y_continuous(name=x_name, limits=c(y_low, y_high))
  p <- p + geom_signif(comparisons = list(c("21", "22")), test=test, map_signif_level=TRUE, y_position = c(2))
  #p <- p + theme_void()
  
  print(p)
  
  #here the order does not matter
  Med_MNC<-na.omit(x[y==21])
  nMed_MNC<-na.omit(x[y==22])
  
  print(summary(Med_MNC))
  
  print(summary(nMed_MNC))
  
  if(test=="wilcox.test"){  
    res<-wilcox.test(Med_MNC, nMed_MNC, alternative = alternative,  exact = FALSE)
  }  
  if(test=="t.test"){  
    res<-t.test(Med_MNC, nMed_MNC, alternative = alternative,  exact = FALSE)
  }
  print(res)
  cat("P-value=", res$p.value)
  
  #return()
}


draw_boxplot3 <- function(x, x_name, y, y_low, y_high, test, alternative){
  #draw_boxplot <- function(x, x_name, y, weight, y_low, y_high){
  options(warn=-1)
  df <- data.frame(x, y)
  #df <- data.frame(x, y, weight)
  
  df <- na.omit(df) #remove missing values
  
  # Box plot with mean points
  p <- ggplot(df, aes(x=y, y=x, fill=y)) + geom_boxplot(notch=FALSE)
  p <- p + stat_summary(fun.y=mean, geom="point", shape=23, size=4) + geom_jitter(shape=16, position=position_jitter(0.2)) + scale_x_discrete(breaks=c("21","22"), labels=c("MNC is covered","MNC is not covered")) +  scale_y_continuous(name=x_name, limits=c(y_low, y_high))
  p <- p + geom_signif(comparisons = list(c("21", "22")), test=test, map_signif_level=TRUE, y_position = c(2))
  #p <- p + theme_void()
  
  print(p)
  
  #here the order does not matter
  Anglophone<-na.omit(x[y=="Anglophone"])
  nonAnglophone<-na.omit(x[y=="nonAnglophone"])
  
  print(summary(Anglophone))
  
  print(summary(nonAnglophone))
  
  if(test=="wilcox.test"){  
    res<-wilcox.test(Anglophone, nonAnglophone, alternative = alternative,  exact = FALSE)
  }  
  if(test=="t.test"){  
    res<-t.test(Anglophone, nonAnglophone, alternative = alternative,  exact = FALSE)
  }
  print(res)
  cat("P-value=", res$p.value)
  
  #return()
}