This readme file accompanies our paper:
Neonatal circumcision and prematurity are associated with Sudden Infant Death Syndrome (SIDS)

The script Main.R contains all commands used to generate the figures and the resutls in the paper.
The script is well annotated with subheading that correspond to those of the paper.

