#-------------------------------------------------------------------------------
# Draw Maps. Figure 1
#-------------------------------------------------------------------------------
rm(list=ls())
print("Draw maps")

library(rworldmap)
library(maptools)

par(mfrow=c(1,1))
a <- read.table("Map_countries.txt", header=T, sep="\t")
a

#dev.new()
SIDS <- data.frame(country = a$ISO3_code, SIDS = a$SIDS)
SIDSMap <- joinCountryData2Map(SIDS, joinCode = "ISO3",nameJoinColumn = "country")
color_vec <- c(0, 0.2, 0.4, 0.6, 0.8, 1, 5)
#tiff(file="Figure1_Countries.tiff", width = 4800, height = 3200, units = "px", res=800)
mapCountryData(SIDSMap, nameColumnToPlot="SIDS", missingCountryCol = gray(1), borderCol = "black", catMethod = color_vec, mapTitle = "Global SIDS prevalence (per 1000 births)")

inFile <- "tl_2009_us_stateec/tl_2009_us_stateec.shp"
sPDF <- readShapePoly(inFile)
str(sPDF@data)
dF <- read.table("Map_states.txt",header=T, sep="\t")
dF
str(dF)
#tiff("Figure1_States.tiff", width = 4800, height = 3200, units = "px", res=800)
sPDF2 <- joinData2Map(dF, nameMap = sPDF , nameJoinIDMap = "STUSPSEC" , nameJoinColumnData = "States")
mapPolys(sPDF2,nameColumnToPlot = "SIDS",mapRegion="North America",missingCountryCol = gray(1), catMethod = color_vec, borderCol = "black", mapTitle = "US SIDS prevalence")


#---------------------------------------------------------------
# Death rates per % of Hispanics in the population (weighted)
# Used in the section: "Mortality rate"
#---------------------------------------------------------------
rm(list=ls())
print("Death rates per % of Hispanics in the population")

#Proportion of Latino/Hispanics from the 2000 census
hisp_prop=0.125

#Load dataset
a <- read.table("Hispanics_Death data - all.txt", header=T, sep="\t", na.strings=".")

#Analyze 2000 data
x=a$Hispanic_2000
y=a$Death_2000
w=a$Populaiton_size_2000

df <- data.frame(x, y, w)
df <- na.omit(df) #remove missing values

#How the unexplained mortality rate in males appears in US states with high/low Hispanics
H_hisp_Death<-df$y[which(df$x>=hisp_prop)]
L_hisp_Death<-df$y[which(df$x<hisp_prop)]
print(c(NROW(H_hisp_Death),NROW(L_hisp_Death), mean(H_hisp_Death)-mean(L_hisp_Death)))

t.test(L_hisp_Death, H_hisp_Death) #two-tailed t-test
boxplot(H_hisp_Death, L_hisp_Death, ylab="Unexplained death rate (per 1000 live births)", names=c("High Hispanic", "Low Hispanic"), main="Comparing Death rates between \n states with high and low Hispanic population", frame=F)

#How the unexplained mortality rate in males is correlated with the percent of Hispanics
mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

cat("2000: N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])


#Analyze 2010 data
x=a$Hispanic_2010
y=a$Death_2010
w=a$Populaiton_size_2000

df <- data.frame(x, y, w)
df <- na.omit(df) #remove missing values

#How the unexplained mortality rate in males appears in US states with high/low Hispanics
H_hisp_Death<-df$y[which(df$x>=hisp_prop)]
L_hisp_Death<-df$y[which(df$x<hisp_prop)]

print(c(NROW(H_hisp_Death),NROW(L_hisp_Death), mean(H_hisp_Death)-mean(L_hisp_Death)))
t.test(L_hisp_Death, H_hisp_Death) #two-tailed t-test
boxplot(H_hisp_Death, L_hisp_Death, ylab="Unexplained death rate (per 1000 live births)", names=c("High Hispanic", "Low Hispanic"), main="Comparing Death rates between \n states with high and low Hispanic population", frame=F)

#How the unexplained mortality rate in males is correlated with the percent of Hispanics
mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

cat("2010: N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])


#Analyze 2012 data
x=a$Hispanic_2012
y=a$Death_2012
w=a$Populaiton_size_2000

df <- data.frame(x, y, w)
df <- na.omit(df) #remove missing values

#How the unexplained mortality rate in males appears in US states with high/low Hispanics
H_hisp_Death<-df$y[which(df$x>=hisp_prop)]
L_hisp_Death<-df$y[which(df$x<hisp_prop)]

print(c(NROW(H_hisp_Death),NROW(L_hisp_Death), mean(H_hisp_Death)-mean(L_hisp_Death)))
t.test(H_hisp_Death, L_hisp_Death) #two-tailed t-test
boxplot(H_hisp_Death, L_hisp_Death, ylab="Unexplained death rate (per 1000 live births)", names=c("High Hispanic", "Low Hispanic"), main="Comparing Death rates between \n states with high and low Hispanic population", frame=F)

#How the unexplained mortality rate in males is correlated with the percent of Hispanics
mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

cat("2012: N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])


#Analyze 2015 data
x=a$Hispanic_2015
y=a$Death_2015
w=a$Populaiton_size_2000

df <- data.frame(x, y, w)
df <- na.omit(df) #remove missing values

#How the unexplained mortality rate in males appears in US states with high/low Hispanics
H_hisp_Death<-df$y[which(df$x>=hisp_prop)]
L_hisp_Death<-df$y[which(df$x<hisp_prop)]

print(c(NROW(H_hisp_Death),NROW(L_hisp_Death), mean(H_hisp_Death)-mean(L_hisp_Death)))
t.test(H_hisp_Death, L_hisp_Death) #two-tailed t-test
boxplot(H_hisp_Death, L_hisp_Death, ylab="Unexplained death rate (per 1000 live births)", names=c("High Hispanic", "Low Hispanic"), main="Comparing Death rates between \n states with high and low Hispanic population", frame=F)

#How the unexplained mortality rate in males is correlated with the percent of Hispanics
mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

cat("2015: N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#Mean reduction in unexplained deaths
mean(c(0.32, 0.53, 0.44, 0.39))

#---------------------------------------------------------------
# Death rates per % of Hispanics in the population (mixed effect model)
#---------------------------------------------------------------
rm(list=ls())
print("Death rates per % of Hispanics in the population")

#Load dataset
a <- read.table("Hispanics_Death data - all.txt", header=T, sep="\t", na.strings=".")

library("lme4")
library("lmerTest")
library("tidyr")

a_long <- gather(a, key, value, Death_2000:Hispanic_2015, factor_key=TRUE)
a_long <- separate(a_long, key, c("measure", "year"), sep = "_")
a2 <- spread(a_long, measure, value)

mix.model <- lmer(Death ~ Hispanic + year + (1|State), data=a2, 
                  weights=(Populaiton_size_2000)/1000)
summary(mix.model)

#-------------------------------------------------------------------------------
# Male death rates vs Hispanics. Figure 2. 
#-------------------------------------------------------------------------------
rm(list=ls())
print("Correlation between Death and % of Hispans in the population  (weighted)")

#Load dataset
a <- read.table("Hispanics_Death data - all.txt", header=T, sep="\t", na.strings=".")

x=a$Hispanic_2015*100
y=a$Death_2015
w=a$Populaiton_size_2000
c=as.character(a$Color_code)

df <- data.frame(x, y, w, c)
df <- na.omit(df) #remove missing values

#model
mod <- lm(y ~ x, data = df, weights = w)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

plot(y ~ x, bg=as.character(c), cex=(sqrt(w)/1000), xlim = c(0, 0.5), ylim = c(0, 2), xlab="Hispanics (%)", ylab="Death prevalence (per 1000 births)", data = df, bty="n", pch=21)

#Model
abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(a), "r =", cor(x, y), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#dev.off()
#tiff(file="Figure 2.tiff", width = 4200, height = 3200, units = "px", res=600)


#---------------------------------------------------------------
#---------------------------------------------------------------
# MNC is positively associated with the risk for early mortality 
#---------------------------------------------------------------
#---------------------------------------------------------------


#-------------------------------------------------------------------------------
#Correlation between Global MNC and SIDS rates (unweighted). 
#Used also in the abstarct
#-------------------------------------------------------------------------------
rm(list=ls())
print("Correlation between Worldwide MNC and SIDS rates (unweighted)")

#Load dataset
a <- read.table("Global_MNC_SIDS.txt", header=T, sep="\t")

x=a$MNC
y=a$SIDS
c=as.character(a$bg)
df <- data.frame(x, y, c)

#Model
mod <- lm(y ~ x, data = df)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

#tiff(file="Figure 3.tiff", width = 4200, height = 3200, units = "px", res=600)
plot(y ~ x, bg=as.character(c), xlim = c(0, 60), ylim = c(0, 1.2), xlab="MNC rate", ylab="SIDS rate", pch=21, data = df, cex=1.5, bty="n")

#Model
abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#Test with MNC rate half 
x=a$MNC.2
y=a$SIDS
w=a$male_births
c=as.character(a$bg)
df <- data.frame(x, y, c, w)
mod <- lm(y ~ x, data = df, weights = w)
summary(mod)
cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#Test with MNC rate double
x=a$MNC.2.1
y=a$SIDS
w=a$male_births
c=as.character(a$bg)
df <- data.frame(x, y, c, w)
mod <- lm(y ~ x, data = df, weights = w)
summary(mod)
cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#-------------------------------------------------------------------------------
#Correlation between Global MNC and SIDS rates (weighted). Figure 3. 
#-------------------------------------------------------------------------------
rm(list=ls())
print("Correlation between Worldwide MNC and SIDS rates (weighted)")

#Load dataset
a <- read.table("Global_MNC_SIDS.txt", header=T, sep="\t")

x=a$MNC
y=a$SIDS
c=as.character(a$bg)
w=a$male_births

df <- data.frame(x, y, c, w)
df <- na.omit(df) #remove missing values

#plot(df$y ~ df$x, bg=as.character(c), xlim = c(0, 60), ylim = c(0, 1.2), xlab="MNC rate", ylab="SIDS rate", pch=21, data = df, cex=1.5, bty="n")
plot(df$y ~ df$x, bg=as.character(c), cex=(sqrt(w)/200), xlim = c(0, 60), ylim = c(0, 1.2), xlab="MNC rate", ylab="SIDS rate", pch=21, data = df, bty="n")

mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#tiff(file="Figure 3.tif", width = 4200, height = 3200, units = "px", res=600)

#Test with MNC rate half 
x=a$MNC.2
y=a$SIDS
w=a$male_births
c=as.character(a$bg)
df <- data.frame(x, y, c, w)
mod <- lm(y ~ x, data = df, weights = w)
summary(mod)
cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#Test with MNC rate double
x=a$MNC.2.1
y=a$SIDS
w=a$male_births
c=as.character(a$bg)
df <- data.frame(x, y, c, w)
mod <- lm(y ~ x, data = df, weights = w)
summary(mod)
cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])


#Test the robustness of the model
n.times=1000
n.points=2
p_vec <- numeric(n.times)
beta_vec <- numeric(n.times)
for (i in 1:n.times)
{
  points_to_drop <- sample(1:NROW(df), n.points)
  df_new = df[-points_to_drop,]
  mod <- lm(y ~ x, data = df_new)
  summary(mod)
  
  p_vec[i]<-summary(mod)$coefficients[2,4]
  beta_vec[i]<-summary(mod)$coefficients[2,1]  
}
#Print results
print(sum(p_vec>0.05)/n.times)
print(mean(beta_vec))


#---------------------------------------------------------------------
# MNC and SIDS rates in Anglophones vs nonAnglophones. Figure 4. 
#---------------------------------------------------------------------
rm(list=ls())
print("MNC and SIDS rates in Anglophones vs nonAnglophones")

#Comparing MNC rates in Anglophone VS non-Anglophone
b <- read.table("Anglophones_nonAnglophones_MNC.txt", header=T)

t.test(b$Anglophone, b$NonAnglophone, var.equal = F) #two-sides t-test

x <- c(b$Anglophone,b$NonAnglophone)
y <- c(rep("Anglophone", NROW(b$Anglophone)), rep("nonAnglophone", NROW(b$NonAnglophone)))
  
DF <- data.frame(x, y)
DF <- na.omit(DF) #remove missing values

#Plot Figure 4 right
source("draw_boxplot2.R")
#tiff(file="Figure 4L.tif", width = 3200, height = 3600, units = "px", res=600)
draw_boxplot3(DF$x, "MNC rate per state", DF$y, 0, 60, 
              test="t.test", alternative="two.sided")
#dev.off()


#Comparing SIDS rates in Anglophone VS non-Anglophone
a <- read.table("Anglophones_nonAnglophones_SIDS.txt", header=T)

t.test(a$Anglophone, a$NonAnglophone, var.equal = F) #two-sides t-test

x <- c(a$Anglophone,a$NonAnglophone)
y <- c(rep("Anglophone", NROW(a$Anglophone)), rep("nonAnglophone", NROW(a$NonAnglophone)))

DF <- data.frame(x, y)
DF <- na.omit(DF) #remove missing values

#Plot Figure 4 right
source("draw_boxplot2.R")
#tiff(file="Figure 4R.tif", width = 3200, height = 3600, units = "px", res=600)
draw_boxplot3(DF$x, "MNC rate per state", DF$y, 0, 1.2, 
              test="t.test", alternative="two.sided")
#dev.off()

#-----------------------------------------------
#Correlation between US MNC and Death rates (unweighted)
#-----------------------------------------------
rm(list=ls())
print("Correlation between US MNC and Death rates (unweighted)")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=c("","NA"))

x=a$MNC_rate*100
y=a$Male_Death
t=a$Medicaid 
c=as.character(a$bg)

df <- data.frame(x, y, t, c)
df <- na.omit(df)

plot(y ~ x, bg=as.character(c), xlim = c(0, 100), ylim = c(0.3, 2.5), xlab="MNC rate", ylab="Death rate", pch=t, data = df, cex=1, bty="n")

mod <- lm(y ~ x, data = df)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#-----------------------------------------------
#Correlation between US MNC and unexplained mortality rates (weighted) Figure 5
#-----------------------------------------------
rm(list=ls())
print("Correlation between US MNC and unexplained mortality rates (weighted)")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$MNC_rate*100
y=a$Male_Death
w=a$Male_Death_Gender_bias_total
c=as.character(a$bg)
t=a$Medicaid 

df <- data.frame(x, y, w, c, t)
df <- na.omit(df) #remove missing values

#plot(y ~ x, bg=as.character(c), xlim = c(0, 100), ylim = c(0.3, 2.5), xlab="MNC rate", ylab="Unexplained mortality rate", pch=t, data = df, cex=1, bty="n")
plot(y ~ x, bg=as.character(c), cex=(sqrt(w)/5), xlim = c(0, 100), ylim = c(0.3, 2.5), xlab="MNC rate", ylab="Unexplained mortality rate", pch=t, data = df, bty="n")

mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')
abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#tiff(file="Figure 5.tif", width = 4200, height = 3200, units = "px", res=600)


#-----------------------------------------------
# Medicaid: MNC and unexplained mortality rates in Medicaid vs non-Medicaid states
# Also used in the abstarct
#-----------------------------------------------
rm(list=ls())
library(ggplot2)
library(ggsignif)
print("Compare unexplained mortality rates in Medicaid vs non-Medicaid states")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

#Compare MNC rates
x1=a$MNC_rate
y<-as.factor(a$Medicaid )

#Compare Mortality rates
DF <- data.frame(x1, y) 
DF <- na.omit(DF) #remove missing values

High<-DF$x1[which(DF$y==21)]
Low<-DF$x1[which(DF$y==22)]
print(c(NROW(High),NROW(Low), median(High), median(Low)))

source("draw_boxplot2.R")

#Plot Figure 6a
draw_boxplot2(DF$x1, "MNC rate per state", DF$y, 0, 1, 
              test="t.test", alternative="two.sided")
#tiff(file="Figure 6a.tiff", width = 4200, height = 3200, units = "px", res=600)

#Compare unexplained mortality rate and gender bias
x3=a$Male_Death

#Compare gender bias in unexplained mortality
DF <- data.frame(x3, y)
DF <- na.omit(DF) #remove missing values

High<-DF$x3[which(DF$y==21)]
Low<-DF$x3[which(DF$y==22)]
print(c(NROW(High),NROW(Low), median(High), median(Low)))
draw_boxplot2(DF$x3, "SIDS rate", DF$y, 0, 2,
              test="t.test", alternative="two.sided")

#-----------------------------------------------
# Gender bias: SIDS gender bias in Medicaid vs non-Medicaid states. Figure 6b
# Also used in the abstarct
#-----------------------------------------------
rm(list=ls())
library(ggplot2)
library(ggsignif)
print("Compare SIDS gender bias in Medicaid vs non-Medicaid states")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

#Compare Death gender bias
x2=a$Male_SIDS_Gender_bias
y<-as.factor(a$Medicaid )

#Compare gender bias 
DF <- data.frame(x2, y)
DF <- na.omit(DF) #remove missing values

High<-DF$x2[which(DF$y==21)]
Low<-DF$x2[which(DF$y==22)]
print(c(NROW(High),NROW(Low), median(High), median(Low)))

source("draw_boxplot2.R")

draw_boxplot2(DF$x2, "SIDS gender bias rate per state", DF$y, 0, 2,
              test="t.test", alternative="two.sided")

#tiff(file="Figure 6b.tiff", width = 4200, height = 3200, units = "px", res=600)

#-----------------------------------------------
#Gender bias: Calculate the male/female SIDS ratio in MNC (unweighted)
# Used in  "MNC is positively associated with the mortality risk"
#-----------------------------------------------
rm(list=ls())
print("male/female SIDS ratio against MNC rate")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$MNC_rate
y=a$Male_SIDS_Gender_bias
c=as.character(a$bg)
t=a$Medicaid 

df <- data.frame(x, y, c, t)
df <- na.omit(df) #remove missing values

#tiff(file="Figure 5.tiff", width = 4200, height = 3200, units = "px", res=600)
plot(df$y ~ df$x, bg=as.character(c), xlim = c(0, 0.8), ylim = c(0.5, 2.5), xlab="MNC rate(%) ", ylab="Male/Female SIDS Ratio", pch=t, data = df, cex=1, bty="n")
grid(nx = NULL, ny = 15, col = "black", lty = "dotted")

mod <- lm(y ~ x, data = df)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#dev.off()

#---------------------------------------------------------------------
#Gender bias: Calculate the male/female ratio in SIDS (weighted) Figure 7a 
#---------------------------------------------------------------------
rm(list=ls())
print("male/female ratio against SIDS rate")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$MNC_rate
y=a$Male_SIDS_Gender_bias
w=a$All_Male_births_ICD30.39
c=as.character(a$bg)
t=a$Medicaid 

df <- data.frame(x, y, w, c, t)
df <- na.omit(df) #remove missing values

mod <- lm(y ~ x, data = df, weights = w)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

#plot(y ~ x, bg=as.character(c), xlim = c(0, 0.8), ylim = c(0.5, 2.5), xlab="MNC rate(%) ", ylab="Male/Female SIDS ratio", pch=t, data = df, cex=1, bty="n")
#grid(nx = NULL, ny = 15, col = "black", lty = "dotted")
plot(y ~ x, bg=as.character(c), cex=(sqrt(w)/100), xlim = c(0, 1), ylim = c(0.5, 2.5), xlab="MNC rate(%) ", ylab="Male/Female SIDS ratio", pch=t, data = df, bty="n")

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

#dev.off()
#tiff(file="Figure 7a.tif", width = 4200, height = 3200, units = "px", res=600)

cat("N =", nrow(df), "r =", cor(df$x, df$y), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#-------------------------------------------------------------------------------
#Gender bias: Compare SIDS Gender bias in Hispanics vs non-Hispanics. Figure 7b
#-------------------------------------------------------------------------------
rm(list=ls())
library(ggplot2)
library(ggsignif)
source("draw_boxplot2.R")
print("Compare unexplained mortality rates in Medicaid vs non-Medicaid states")

#Load dataset
a <- read.table("Hispanics_Gender_bias.txt", header=T, sep="\t", na.strings=".")

#Compare MNC rates
x<-factor(a$Pop, levels=unique(a$Pop))
y=a$Bias
  
#Compare SIDs rates
df <- data.frame(x, y)
    
# Box plot with mean points
p <- ggplot(df, aes(x=x, y=y, color=y, fill=x)) + geom_boxplot(notch=FALSE) + scale_fill_manual(values=c("green", "orange", "yellow"))
p <- p + stat_summary(fun.y=mean, geom="point", shape=23, size=4) + geom_jitter(shape=16, position=position_jitter(0.2))  
p <- p + geom_signif(comparisons = list(c("HW", "NHW"), c("HW", "NHB"), c("NHW", "NHB")), margin_top = 0.1, stat = "signif", test="t.test", map_signif_level=TRUE, y_position = c(1.9, 1.8, 1.7) )
p <- p + scale_y_continuous(name="SIDS gender bias" , limits=c(0, 2))
#p <- p + theme_void()
print(p)

#tiff(file="Figure 5c.tiff", width = 4200, height = 3200, units = "px", res=600)

#Calculate the statistics
HW<-y[which(x=="HW")]
NHW<-y[which(x=="NHW")]
NHB<-y[which(x=="NHB")]

t.test(HW, NHW)
t.test(HW, NHB, alternative="less")
t.test(NHB, NHW, alternative="less")


#---------------------------------------------------------------
#---------------------------------------------------------------
# Prematurity is positively associated with the risk for mortality
#---------------------------------------------------------------
#---------------------------------------------------------------


#---------------------------------------------------------------
# Preterm: Global SIDS rates versus preterm rate (unweighted). 
#---------------------------------------------------------------
rm(list=ls())
print("Test association between SIDS and preterm rates in worldwide popualtions")

a <- read.table("Global_SIDS_prematurity.txt", header=T)

x=a$Preterm
y=a$SIDS
c=as.character(a$bg)

df <- data.frame(x, y, c)

plot(y ~ x, xlim = c(5, 20), ylim = c(0, 1.2), bg = as.character(c), xlab="Preterm birth rate(%) ", ylab="SIDS prevalence (per 1000 birth) ", pch=21, col='black', data = df, cex=1, bty="n")

mod <- lm(y ~ x, data = df)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

summary(mod)
cat("N =", nrow(a), "r =", cor(a$Preterm, a$SIDS), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#---------------------------------------------------------------
# Preterm: Global SIDS rates versus preterm rate (weighted) Figure 8
#---------------------------------------------------------------
rm(list=ls())
print("Test association between SIDS and preterm rates in worldwide popualtions")

a <- read.table("Global_SIDS_prematurity.txt", header=T)

x=a$Preterm
y=a$SIDS
w=a$male_births
c=as.character(a$bg)

df <- data.frame(x, y, w, c)

plot(y ~ x, xlim = c(5, 20), ylim = c(0, 1.2), bg = as.character(c), 
     cex = sqrt(w)/200, xlab="Preterm birth rate(%) ", ylab="SIDS prevalence (per 1000 birth) ", pch=21, col='black', data = df, bty="n")

mod <- lm(y ~ x, data = df, weights = w)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(a), "r =", cor(a$Preterm, a$SIDS), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
tiff(file="Figure 8.tif", width = 4200, height = 3200, units = "px", res=600)

#---------------------------------------------------------------
# Preterm: US SIDS versus preterm rate. (unweighted)
#---------------------------------------------------------------
rm(list=ls())
print("US SIDS versus preterm rate")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$Preterm_rate
y=a$Male_Death
c=as.character(a$bg)
t=a$Medicaid 

df <- data.frame(x, y, c, t)
df <- na.omit(df) #remove missing values

plot(y ~ x, bg=as.character(c), xlim = c(8, 13), ylim = c(0.1, 2.5), xlab="Preterm rate", ylab="Death rate", pch=t, data = df, cex=1, bty="n")

mod <- lm(y ~ x, data = df)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#---------------------------------------------------------------
# Preterm: US Death versus preterm rate (weighted). Figure 9
#---------------------------------------------------------------
rm(list=ls())
print("US Death versus preterm rate")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$Preterm_rate
y=a$Male_Death
w=a$Preterm_num
c=as.character(a$bg)
t=a$Medicaid 

df <- data.frame(x, y, c, w, t)
df <- na.omit(df) #remove missing values

#plot(y ~ x, bg=as.character(c), xlim = c(8, 13), ylim = c(0.1, 2.5), xlab="Preterm rate", ylab="Death rate", pch=t, data = df, cex=1, bty="n")
plot(y ~ x, bg=as.character(c), cex = sqrt(w)/50, xlim = c(8, 13), ylim = c(0.1, 2.5), xlab="Preterm rate", ylab="Death rate", pch=t, data = df, bty="n")

mod <- lm(y ~ x, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

# predicts + interval
newx <- seq(min(df$x), max(df$x), length.out=100)
preds <- predict(mod, newdata = data.frame(x=newx), 
                 interval = 'confidence')

abline(mod)
lines(newx, preds[ ,2], lty = 'dashed', col = 'black')
lines(newx, preds[ ,3], lty = 'dashed', col = 'black')

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])
#tiff(file="Figure 9.tif", width = 4200, height = 3200, units = "px", res=800)

#---------------------------------------------------------------
# Preterm: US preterm rate versus SIDS gender bias. 
#---------------------------------------------------------------
rm(list=ls())
print("US preterm rate versus SIDS gender bias")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$Preterm_rate
y=a$Male_SIDS_Gender_bias  

df <- data.frame(x, y)
df <- na.omit(df) #remove missing values

plot(y ~ x, xlab="Preterm rate", ylab="SIDS gender bias",data = df, cex=1, bty="n")

mod <- lm(y ~ x, data = df)
summary(mod)

#Calculate CI
confint(mod)

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#---------------------------------------------------------------
# Preterm: US MNC versus preterm rate. 
#---------------------------------------------------------------
rm(list=ls())
print("US MNC versus preterm rate")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$Preterm_rate
y=a$MNC_rate

df <- data.frame(x, y)
df <- na.omit(df) #remove missing values

plot(y ~ x, xlab="Preterm rate", ylab="MNC rate",data = df, cex=1, bty="n")

#Calculate CI
confint(mod)

mod <- lm(y ~ x, data = df)
summary(mod)
cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#---------------------------------------------------------------
# Preterm: Global MNC versus preterm rate. 
#---------------------------------------------------------------
rm(list=ls())
print("Global MNC versus preterm rate")

#Load dataset
a <- read.table("Global_SIDS_prematurity.txt", header=T, sep="\t", na.strings=".")

x=a$Preterm_rate
y=a$MNC_rate

df <- data.frame(x, y)
df <- na.omit(df) #remove missing values

plot(y ~ x, xlab="Preterm rate", ylab="MNC rate",data = df, cex=1, bty="n")

mod <- lm(y ~ x, data = df)
summary(mod)

#Calculate CI
confint(mod)

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

#---------------------------------------------------------------
#---------------------------------------------------------------
# Additive effects of various phenotypes increase the risk of early mortality
#---------------------------------------------------------------
#---------------------------------------------------------------


#---------------------------------------------------------------
# Multivariate model (US): Unexplained mortality, Region, MNC, preterm rate 
#---------------------------------------------------------------
rm(list=ls())
print("Multivariate model (US): explaining unexplained mortality rates using region, MNC, and preterm rate")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$Male_Death
y=a$MNC_rate*100
z=a$Preterm_rate
r=a$Regions

w=a$All_Male_births_ICD30.39

df <- data.frame(x, y, z, r, w)
df <- na.omit(df) #remove missing values

mod <- lm(x ~ y+r+z, data = df, weights=w)
summary(mod)

#Calculate CI
confint(mod)

cat("N =", nrow(df), "r =", cor(df$x, df$y, use="complete.obs"), "R^2 =", summary(mod)$r.squared, "P-value=", coef(summary(mod)) [8])

# Investigate interactions between these factors and carry out backwards stepwise regression
# taking out the least significant term each time. No interactions are significant in this model and neither
# is preterm rate.

#backwards regression:
mod1 <- lm(x ~ y*r*z, data = df, weights=w)
anova(mod1)
mod2 <- lm(x ~ y*r + y*z + r*z, data = df, weights=w)
anova(mod2)
mod3 <- lm(x ~ y*z + r*z, data = df, weights=w)
anova(mod3)
mod4 <- lm(x ~ y + r*z, data = df, weights=w)
anova(mod4)
mod5 <- lm(x ~ y + r + z, data = df, weights=w)
anova(mod5) # same as mod below
mod6 <- lm(x ~ y + r, data = df, weights=w)
anova(mod6)
summary(mod6)

#---------------------------------------------------------------
# LRT: Likelihood ratio test for the Global dataset (weighted))
#---------------------------------------------------------------
rm(list=ls())
library(lmtest)
print("Likelihood ratio (countries)")

#Load dataset
a <- read.table("Multfact2factors_countries.txt", header=T, sep="\t")

#Define models to test
model0 <- glm(a$Male_SIDS ~ a$MNC_rate, weights = a$All_Male_births_ICD30.39)
model1 <- glm(a$Male_SIDS ~ a$Preterm_rate, weights = a$All_Male_births_ICD30.39)
model3 <- glm(a$Male_SIDS ~ a$MNC_rate+a$Preterm_rate, weights = a$All_Male_births_ICD30.39)

#Compare models
lrtest (model0, model3) # MNC vs. MNC+Preterm
lrtest (model1, model3) # Preterm vs. MNC+Preterm

# Again, you could consider interaction, but again they are not significant,
# so it doesn't really matter

#---------------------------------------------------------------
# LRT: Likelihood ratio test for states (weighted)
#---------------------------------------------------------------
#library(lmtest)
rm(list=ls())
print("Likelihood ratio (states)")

#Load dataset
a <- read.table("US data 2013.txt", header=T, sep="\t", na.strings=".")

x=a$Male_Death
y=a$MNC_rate
r=a$Preterm_rate
w=a$All_Male_births_ICD30.39 

df <- data.frame(x, y, r, w)
df <- na.omit(df) #remove missing values

#Define models to test
model0 <- glm(x ~ y, data = df, weights = w)
model1 <- glm(x ~ r, data = df, weights = w)
model3 <- glm(x ~ y+r, data = df, weights = w)

#Compare models
lrtest (model0, model3) # MNC vs. MNC+Preterm
lrtest (model1, model3) # Preterm vs. MNC+Preterm
